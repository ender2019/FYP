from django.urls import path
from .views import (
    PostListView,
    PostDetailView,
    PostCreateView,
    PostUpdateView,
    PostDeleteView,
    UserPostListView
)
from . import views

urlpatterns = [
    path('', PostListView.as_view(), name='blog-home'),
    path('user/<str:username>', UserPostListView.as_view(), name='user-posts'),
    path('post/<int:pk>/', PostDetailView.as_view(), name='post-detail'),
    path('post/new/', PostCreateView.as_view(), name='post-create'),
    path('post/<int:pk>/update/', PostUpdateView.as_view(), name='post-update'),
    path('post/<int:pk>/delete/', PostDeleteView.as_view(), name='post-delete'),
    path('about/', views.about, name='blog-about'),
    path('shopp/', views.shopp, name='blog-shopp'),
    path('Eat_At_Japan/', views.Eat_At_Japan, name='blog-Eat_At_Japan'),
    path('loskak/', views.loskak, name='blog-loskak'),
    path('line/', views.line, name='blog-line'),
    path('ltokyo/', views.ltokyo, name='blog-ltokyo'),
    path('lhokkaido/', views.lhokkaido, name='blog-lhokkaido'),
    path('lsapporo/', views.lsapporo, name='blog-lsapporo'),
    path('ltsruimura/', views.ltsruimura, name='blog-ltsruimura'),
    path('lall/', views.lall, name='blog-lall'),
    path('lkanto/', views.lkanto, name='blog-lkanto'),
    path('lchubu/', views.lchubu, name='blog-lchubu'),
    path('lkinki/', views.lkinki, name='blog-lkinki'),
    path('lkyusyu/', views.lkyusyu, name='blog-lkyusyu'),
    path('lchugoku/', views.lchugoku, name='blog-lchugoku'),
    path('lshikoku/', views.lshikoku, name='blog-lshikoku'),
    path('ltohoku/', views.ltohoku, name='blog-ltohoku'),
    path('hotel/', views.hotel, name='blog-hotel'),
    path('hall/', views.hall, name='blog-hall'),
    path('htsruimura/', views.htsruimura, name='blog-htsruimura'),
    path('hsapporo/', views.hsapporo, name='blog-hsapporo'),
    path('hhokkaido/', views.hhokkaido, name='blog-hhokkaido'),
    path('hkinki/', views.hkinki, name='blog-hkinki'),
    

path('fkanto/', views.fkanto, name='blog-fkanto'),
path('food/', views.food, name='blog-food'),
path('fsushi/', views.fsushi, name='blog-fsushi'),
path('fsushim/', views.fsushim, name='blog-fsushim'),
path('ftokyo/', views.ftokyo, name='blog-ftokyo'),

    path('ShopOsaka/', views.ShopOsaka, name='blog-ShopOsaka'),
    path('ShopTokyo/', views.ShopTokyo, name='blog-ShopTokyo'),
    path('ShopNagoya/', views.ShopNagoya, name='blog-ShopNagoya'),
    path('ShopMatsuzakaya/', views.ShopMatsuzakaya, name='blog-ShopMatsuzakaya'),
    path('ShopDaimaru/', views.ShopDaimaru, name='blog-ShopDaimaru'),
    path('ShopHankyu/', views.ShopHankyu, name='blog-ShopHankyu'),
    path('ShopNagoya/', views.ShopNagoya, name='blog-ShopNagoya'),
    path('ShopTokyostreet/', views.ShopTokyostreet, name='blog-ShopTokyostreet'),
    path('ShopKyotostreet/', views.ShopKyotostreet, name='blog-ShopKyotostreet'),
    path('ShopOsakastreet/', views.ShopOsakastreet, name='blog-ShopOsakastreet'),
    path('ShopJapaneseConfectionery/', views.ShopJapaneseConfectionery, name='blog-ShopJapaneseConfectionery'),
    path('ShopJapanesedrinks/', views.ShopJapanesedrinks, name='blog-ShopJapanesedrinks'),
    path('ShopJapaneseporcelain/', views.ShopJapaneseporcelain, name='blog-ShopJapaneseporcelain'),
    path('ShopJapanesenote/', views.ShopJapanesenote, name='blog-ShopJapanesenote'),
    path('ShopJapaneseconsumptiontax/', views.ShopJapaneseconsumptiontax, name='blog-ShopJapaneseconsumptiontax'),
    path('ShopDutyfree/', views.ShopDutyfree, name='blog-ShopDutyfree'),
    
    
]
