from django.shortcuts import render, get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.models import User
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView
)
from .models import Post


def home(request):
    context = {
        'posts': Post.objects.all()
    }
    return render(request, 'blog/home.html', context)

def Eat_At_Japan(request):
    return render(request, 'blog/Eat_At_Japan.html', {'title': 'Eat_At_Japan'})

def line(request):
    return render(request, 'blog/line.html', {'title': 'line'})

def loskak(request):
    return render(request, 'blog/loskak.html', {'title': 'loskak'})

def shopp(request):
    return render(request, 'blog/shopp.html', {'title': 'Shopp'})

def ltokyo(request):
    return render(request, 'blog/ltokyo.html', {'title': 'ltokyo'})

def lhokkaido(request):
    return render(request, 'blog/lhokkaido.html', {'title': 'lhokkaido'})

def lsapporo(request):
    return render(request, 'blog/lsapporo.html', {'title': 'lsapporo'})

def ltsruimura(request):
    return render(request, 'blog/ltsruimura.html', {'title': 'ltsruimura'})

def lkanto(request):
    return render(request, 'blog/lkanto.html', {'title': 'lkanto'})

def lkinki(request):
    return render(request, 'blog/lkinki.html', {'title': 'lkinki'})

def lkyusyu(request):
    return render(request, 'blog/lkyusyu.html', {'title': 'lkyusyu'})

def lshikoku(request):
    return render(request, 'blog/lshikoku.html', {'title': 'lshikoku'})

def ltohoku(request):
    return render(request, 'blog/ltohoku.html', {'title': 'ltohoku'})

def lchugoku(request):
    return render(request, 'blog/lchugoku.html', {'title': 'lchugoku'})

def lchubu(request):
    return render(request, 'blog/lchubu.html', {'title': 'lchubu'})

def lall(request):
    return render(request, 'blog/lall.html', {'title': 'lall'})

def hotel(request):
    return render(request, 'blog/hotel.html', {'title': 'hotel'})

def hall(request):
    return render(request, 'blog/hall.html', {'title': 'hall'})

def htsruimura(request):
    return render(request, 'blog/htsruimura.html', {'title': 'htsruimura'})

def hsapporo(request):
    return render(request, 'blog/hsapporo.html', {'title': 'hsapporo'})

def hhokkaido(request):
    return render(request, 'blog/hhokkaido.html', {'title': 'hhokkaido'})
    
def hkinki(request):
    return render(request, 'blog/hkinki.html', {'title': 'hkinki'})    
    
    
    
def food(request):
    return render(request, 'blog/Food.html', {'title': 'food'})

def fsushim(request):
    return render(request, 'blog/fsushim.html', {'title': 'fsushim'})

def fsushi(request):
    return render(request, 'blog/fsushi.html', {'title': 'fsushi'})

def ftokyo(request):
    return render(request, 'blog/ftokyo.html', {'title': 'ftokyo'})

def fkanto(request):
    return render(request, 'blog/fkanto.html', {'title': 'fkanto'})

def ShopOsaka(request):
    return render(request, 'blog/ShopOsaka.html', {'title': 'ShopOsaka'})

def ShopTokyo(request):
    return render(request, 'blog/ShopTokyo.html', {'title': 'ShopTokyo'})
    
def ShopNagoya(request):
    return render(request, 'blog/ShopNagoya.html', {'title': 'ShopNagoya'})    
    
def ShopMatsuzakaya(request):
    return render(request, 'blog/ShopMatsuzakaya.html', {'title': 'ShopMatsuzakaya'})      

   
def ShopDaimaru(request):
    return render(request, 'blog/ShopDaimaru.html', {'title': 'ShopDaimaru'})     
  
def ShopHankyu(request):
    return render(request, 'blog/ShopHankyu.html', {'title': 'ShopHankyu'})  
    
def ShopTokyostreet(request):
    return render(request, 'blog/ShopTokyostreet.html', {'title': 'ShopTokyostreet'})    
    
def ShopKyotostreet(request):
    return render(request, 'blog/ShopKyotostreet.html', {'title': 'ShopKyotostreet'})     
    
def ShopOsakastreet(request):
    return render(request, 'blog/ShopOsakastreet.html', {'title': 'ShopOsakastreet'})     
   
def ShopJapaneseConfectionery(request):
    return render(request, 'blog/ShopJapaneseConfectionery.html', {'title': 'ShopJapaneseConfectionery'})       
    
def ShopJapanesedrinks(request):
    return render(request, 'blog/ShopJapanesedrinks.html', {'title': 'ShopJapanesedrinks'})       
        
def ShopJapaneseporcelain(request):
    return render(request, 'blog/ShopJapaneseporcelain.html', {'title': 'ShopJapaneseporcelain'})    
    
def ShopJapanesenote(request):
    return render(request, 'blog/ShopJapanesenote.html', {'title': 'ShopJapanesenote'})        

def ShopJapaneseconsumptiontax(request):
    return render(request, 'blog/ShopJapaneseconsumptiontax.html', {'title': 'ShopJapaneseconsumptiontax'})

def ShopDutyfree(request):
    return render(request, 'blog/ShopDutyfree.html', {'title': 'ShopDutyfree'})
    
    
def Shopnotice(request):
    return render(request, 'blog/Shopnotice.html', {'title': 'Shopnotice'})

class PostListView(ListView):
    model = Post
    template_name = 'blog/home.html'  # <app>/<model>_<viewtype>.html
    context_object_name = 'posts'
    ordering = ['-date_posted']
    paginate_by = 5


class UserPostListView(ListView):
    model = Post
    template_name = 'blog/user_posts.html'  # <app>/<model>_<viewtype>.html
    context_object_name = 'posts'
    paginate_by = 5

    def get_queryset(self):
        user = get_object_or_404(User, username=self.kwargs.get('username'))
        return Post.objects.filter(author=user).order_by('-date_posted')


class PostDetailView(DetailView):
    model = Post


class PostCreateView(LoginRequiredMixin, CreateView):
    model = Post
    fields = ['title', 'content']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)


class PostUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Post
    fields = ['title', 'content']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False


class PostDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Post
    success_url = '/'

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False


def about(request):
    return render(request, 'blog/about.html', {'title': 'About'})

