from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse


class Post(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    date_posted = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'pk': self.pk})

class User(models.Model):
    uid = models.AutoField(primary_key=True)
    nick = models.CharField(max_length=16)
    passwd = models.CharField(max_length=32)
    email = models.CharField(max_length=128)
    birth = models.CharField(max_length=16)
    address = models.CharField(max_length=255, null=True)
    tel = models.CharField(max_length=32, null=True)

class Lineallplace(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')


class Lineregion(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    area = models.CharField(max_length=16)
    name = models.CharField(max_length=256)
    namedetail = models.CharField(max_length=1024)
    areapic = models.ImageField(upload_to='images/')
    Lineafk = models.ForeignKey(Lineallplace, default=1 ,verbose_name= "uid", on_delete=models.SET)


class Linefamous(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    area = models.CharField(max_length=16)
    name = models.CharField(max_length=256)
    namedetail = models.CharField(max_length=1024)
    areapic = models.ImageField(upload_to='images/')
    Lineafk = models.ForeignKey(Lineallplace, default=1 ,verbose_name= "id", on_delete=models.SET)

class Linespecial(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    area = models.CharField(max_length=16)
    name = models.CharField(max_length=256)
    namedetail = models.CharField(max_length=1024)
    areapic = models.ImageField(upload_to='images/')
    Lineafk = models.ForeignKey(Lineallplace, default=1 ,verbose_name= "id", on_delete=models.SET)

class Linerecommend(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    area = models.CharField(max_length=16)
    name = models.CharField(max_length=256)
    namedetail = models.CharField(max_length=1024)
    areapic = models.ImageField(upload_to='images/')


class Lineroute(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    name = models.CharField(max_length=16)
    details = models.CharField(max_length=256)
    namepic = models.ImageField(upload_to='images/')

class Line(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    lineffk = models.ForeignKey(Linefamous, default=1 ,verbose_name= "id", on_delete=models.SET)
    Lineafk = models.ForeignKey(Lineallplace, default=1 ,verbose_name= "id", on_delete=models.SET)
    linerfk = models.ForeignKey(Lineregion, default=1 ,verbose_name= "id", on_delete=models.SET)
    linesfk = models.ForeignKey(Linespecial, default=1 ,verbose_name= "id", on_delete=models.SET)
    linerefk = models.ForeignKey(Linerecommend, default=1 ,verbose_name= "id", on_delete=models.SET)
    lineroutefk = models.ForeignKey(Lineroute, default=1 ,verbose_name= "id", on_delete=models.SET)

class Hotelallplace(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')

class Hotelregion(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=16)
    namepic = models.ImageField(upload_to='images/')
    hotelafk = models.ForeignKey(Hotelallplace, default=1 ,verbose_name= "id", on_delete=models.SET)

class Hotelfamous(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=16)
    namepic = models.ImageField(upload_to='images/')
    hotelafk = models.ForeignKey(Hotelallplace, default=1 ,verbose_name= "id", on_delete=models.SET)

class Hoteldiscount(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=16)
    namepic = models.ImageField(upload_to='images/')
    hotelafk = models.ForeignKey(Hotelallplace, default=1 ,verbose_name= "id", on_delete=models.SET)


class Hotelspecial(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    area = models.CharField(max_length=16)
    name = models.CharField(max_length=256)
    namedetail = models.CharField(max_length=1024)
    areapic = models.ImageField(upload_to='images/')
    hotelafk = models.ForeignKey(Hotelallplace, default=1 ,verbose_name= "id", on_delete=models.SET)


class Hotelrecommend(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    area = models.CharField(max_length=16)
    name = models.CharField(max_length=256)
    namedetail = models.CharField(max_length=1024)
    areapic = models.ImageField(upload_to='images/')


class Hotelad(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    name = models.CharField(max_length=16)
    namepic = models.ImageField(upload_to='images/')

class Hotel(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    hotelffk = models.ForeignKey(Hotelfamous, default=1 ,verbose_name= "id", on_delete=models.SET)
    hotelafk = models.ForeignKey(Hotelallplace, default=1 ,verbose_name= "id", on_delete=models.SET)
    hotelrfk = models.ForeignKey(Hotelregion, default=1 ,verbose_name= "id", on_delete=models.SET)
    hotelsfk = models.ForeignKey(Hotelspecial, default=1 ,verbose_name= "id", on_delete=models.SET)
    hotelrefk = models.ForeignKey(Hotelrecommend, default=1 ,verbose_name= "id", on_delete=models.SET)
    hoteladfk = models.ForeignKey(Hotelad, default=1 ,verbose_name= "id", on_delete=models.SET)
    hoteldfk = models.ForeignKey(Hoteldiscount, default=1, verbose_name="id", on_delete=models.SET)

class Shopallitems(models.Model):
    id = models.AutoField(primary_key=True)
    categories = models.CharField(max_length=32)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')

class Shopregion(models.Model):
    id = models.AutoField(primary_key=True)
    categories = models.CharField(max_length=32)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')

class Shopnotice(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=16)
    namepic = models.ImageField(upload_to='images/')

class Shopinfo(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=16)
    namepic = models.ImageField(upload_to='images/')

class Shopfamous(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=16)
    categories = models.CharField(max_length=32)
    namepic = models.ImageField(upload_to='images/')
    Shopafk = models.ForeignKey(Shopallitems, default=1 ,verbose_name= "id", on_delete=models.SET)

class Shopspecial(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    area = models.CharField(max_length=16)
    name = models.CharField(max_length=256)
    categories = models.CharField(max_length=32)
    namedetail = models.CharField(max_length=1024)
    areapic = models.ImageField(upload_to='images/')
    Shopafk = models.ForeignKey(Shopallitems, default=1, verbose_name="id", on_delete=models.SET)

class Shoppromo(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    area = models.CharField(max_length=16)
    name = models.CharField(max_length=256)
    categories = models.CharField(max_length=32)
    namedetail = models.CharField(max_length=1024)
    areapic = models.ImageField(upload_to='images/')


class Shopad(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    name = models.CharField(max_length=16)
    categories = models.CharField(max_length=32)
    namepic = models.ImageField(upload_to='images/')

class Shop(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    Shopffk = models.ForeignKey(Shopfamous, default=1 ,verbose_name= "id", on_delete=models.SET)
    Shopnfk = models.ForeignKey(Shopnotice, default=1, verbose_name="id", on_delete=models.SET)
    Shopafk = models.ForeignKey(Shopallitems, default=1 ,verbose_name= "id", on_delete=models.SET)
    Shoprfk = models.ForeignKey(Shopregion, default=1, verbose_name="id", on_delete=models.SET)
    Shopifk = models.ForeignKey(Shopinfo, default=1 ,verbose_name= "id", on_delete=models.SET)
    Shopsfk = models.ForeignKey(Shopspecial, default=1 ,verbose_name= "id", on_delete=models.SET)
    Shopprfk = models.ForeignKey(Shoppromo, default=1 ,verbose_name= "id", on_delete=models.SET)
    Shopadfk = models.ForeignKey(Shopad, default=1 ,verbose_name= "id", on_delete=models.SET)

class Foodcategoriesnotice(models.Model):
    id = models.AutoField(primary_key=True)
    categories = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')

class Foodallcategories(models.Model):
    id = models.AutoField(primary_key=True)
    categories = models.CharField(max_length=32)
    area = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    Foodacfk = models.ForeignKey(Foodcategoriesnotice, default=1, verbose_name="id", on_delete=models.SET)

class Foodregion(models.Model):
    id = models.AutoField(primary_key=True)
    categories = models.CharField(max_length=32)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    area = models.CharField(max_length=32)
    pic = models.ImageField(upload_to='images/')
    Foodafk = models.ForeignKey(Foodallcategories, default=1 ,verbose_name= "id", on_delete=models.SET)

class Foodfamous(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=16)
    categories = models.CharField(max_length=32)
    namepic = models.ImageField(upload_to='images/')
    Foodafk = models.ForeignKey(Foodallcategories, default=1 ,verbose_name= "id", on_delete=models.SET)

class Foodspecial(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    area = models.CharField(max_length=16)
    name = models.CharField(max_length=256)
    categories = models.CharField(max_length=32)
    namedetail = models.CharField(max_length=1024)
    areapic = models.ImageField(upload_to='images/')
    Foodafk = models.ForeignKey(Foodallcategories, default=1 ,verbose_name= "id", on_delete=models.SET)


class Foodpromo(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    area = models.CharField(max_length=16)
    name = models.CharField(max_length=256)
    categories = models.CharField(max_length=32)
    namedetail = models.CharField(max_length=1024)
    areapic = models.ImageField(upload_to='images/')
    Foodafk = models.ForeignKey(Foodallcategories, default=1, verbose_name="id", on_delete=models.SET)

class Foodad(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    name = models.CharField(max_length=16)
    categories = models.CharField(max_length=32)
    namepic = models.ImageField(upload_to='images/')

class Food(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32)
    detail = models.CharField(max_length=255)
    pic = models.ImageField(upload_to='images/')
    Foodffk = models.ForeignKey(Foodfamous, default=1 ,verbose_name= "id", on_delete=models.SET)
    Foodafk = models.ForeignKey(Foodallcategories, default=1 ,verbose_name= "id", on_delete=models.SET)
    Foodrfk = models.ForeignKey(Foodregion, default=1, verbose_name="id", on_delete=models.SET)
    Foodsfk = models.ForeignKey(Foodspecial, default=1 ,verbose_name= "id", on_delete=models.SET)
    Foodprfk = models.ForeignKey(Foodpromo, default=1 ,verbose_name= "id", on_delete=models.SET)
    Foodadfk = models.ForeignKey(Foodad, default=1 ,verbose_name= "id", on_delete=models.SET)


class Website(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=32, null=True)
    keyword = models.CharField(max_length=255, null=True)
    img = models.ImageField(upload_to='images/')
    userfk = models.ForeignKey(User, default=1 ,verbose_name= "uid", on_delete=models.SET)
    Linefk = models.ForeignKey(Line, default=1 ,verbose_name= "uid", on_delete=models.SET)
    Foodfk = models.ForeignKey(Food, default=1 ,verbose_name= "uid", on_delete=models.SET)
    Hotelfk = models.ForeignKey(Hotel, default=1 ,verbose_name= "uid", on_delete=models.SET)